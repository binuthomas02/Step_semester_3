package constructors_java_keywords.assigment_problems;

public class CanteenInventoryRestock {

    static class Item {
        String itemName;
        int stock;

        public Item(String itemName, int stock) {
            this.itemName = itemName;
            this.stock = stock;
        }

        void restock(int stock) {
            this.stock += stock;
        }
    }

    public static void main(String[] args) {
        Item[] items = new Item[4];
        items[0] = new Item("Samosa", 15);
        items[1] = new Item("Tea Powder", 40);
        items[2] = new Item("Bread", 8);
        items[3] = new Item("Biscuit Packs", 25);

        for (Item item : items) {
            item.restock(20);
            System.out.println(item.itemName + " | Final Stock: " + item.stock);
        }
    }
}
