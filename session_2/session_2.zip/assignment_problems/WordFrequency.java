import java.util.*;

class WordFrequency
{
    static void printFilteredWordFrequency(String feedback)
    {
        String[] stopWords = {"the", "was", "and", "a", "is", "of", "in"};

        feedback = feedback.toLowerCase();
        feedback = feedback.replace(".", "");
        feedback = feedback.replace(",", "");

        String[] words = feedback.split("\\s+");

        HashMap<String, Integer> frequency = new HashMap<>();

        for(String word : words)
        {
            boolean isStopWord = false;

            for(String stop : stopWords)
            {
                if(word.equals(stop))
                {
                    isStopWord = true;
                    break;
                }
            }

            if(!isStopWord)
            {
                frequency.put(word, frequency.getOrDefault(word, 0) + 1);
            }
        }

        List<Map.Entry<String, Integer>> list =
            new ArrayList<>(frequency.entrySet());

        list.sort((a, b) -> b.getValue() - a.getValue());

        for(Map.Entry<String, Integer> entry : list)
        {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        String feedback = sc.nextLine();

        printFilteredWordFrequency(feedback);
    }
}